PICO 2 SYNTH WORKSHOP - Setup Guide
====================================

This bundle contains everything needed to get your Pico running
as a configurable synthesizer.

CONTENTS
--------
  circuitpython-pico2-en_US-10.2.0.uf2  - CircuitPython for Pico 2 (RP2350)
  circuitpython-pico-en_US-10.2.0.uf2   - CircuitPython for Pico 1 (RP2040)
  CIRCUITPY/                             - Files to copy to your board

STEP 1: Install CircuitPython
------------------------------
  1. Unplug your Pico from USB.
  2. Hold the BOOTSEL button while plugging it into USB.
  3. A drive called "RPI-RP2" (or "RP2350") will appear.
  4. Drag the correct .uf2 file onto that drive:
       - Pico 2 (RP2350): circuitpython-pico2-en_US-10.2.0.uf2
       - Pico 1 (RP2040): circuitpython-pico-en_US-10.2.0.uf2
  5. The board will reboot and a drive called "CIRCUITPY" will appear.

STEP 2: Copy Firmware Files
----------------------------
  1. Open the CIRCUITPY drive on your computer.
  2. Delete any existing code.py and lib/ folder on the drive.
  3. Copy the contents of the CIRCUITPY/ folder from this bundle
     onto the CIRCUITPY drive:
       - code.py
       - lib/  (entire folder)
  4. The board will auto-restart and begin running.

STEP 3: Configure via Web
--------------------------
  1. Open the web configurator:
     https://drc3p0.github.io/Pico-2-Synth-workshop-v2/
  2. Click "Connect" and select your Pico's serial port.
  3. Drag parameters and keys into the Active Hardware Zone.
  4. Assign hardware types (button, pot, touch) and GPIO pins.
  5. Click "Save to Device" to push your configuration.

TROUBLESHOOTING
---------------
  - If CIRCUITPY drive doesn't appear after Step 1, try again.
    Make sure you hold BOOTSEL before plugging in.
  - If the synth doesn't respond, check that code.py and lib/
    are at the root of the CIRCUITPY drive (not inside a subfolder).
  - Audio output is on GP13 by default (PWM audio).
